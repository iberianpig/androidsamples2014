package com.mamezou.android.ui.oxgame.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageButton;

import com.mamezou.android.ui.oxgame.Flag;

public class RectButton extends ImageButton {

	private Flag flag = Flag.None;

	public RectButton(Context context) {
		super(context);
	}

	public RectButton(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public RectButton(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	public Flag getFlag() {
		return flag;
	}

	public void setFlag(Flag flag) {
		this.flag = flag;
		switch (flag) {
		case Black:
			setBackgroundResource(com.mamezou.android.ui.oxgame.R.drawable.black);
			break;
		case White:
			setBackgroundResource(com.mamezou.android.ui.oxgame.R.drawable.white);
			break;
		case None:
			setBackgroundResource(com.mamezou.android.ui.oxgame.R.drawable.none);
		}
	}

	public boolean hasFlag() {
		return flag != Flag.None;
	}
}
