package com.mamezou.android.ui.oxgame;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.mamezou.android.ui.oxgame.widget.RectButton;

public class OXGameActivity extends Activity {
  // すべてのImageButtonに同じ処理をすることが多いのでリストを作成しておく。
  private RectButton[] rectButtons = new RectButton[9];
  // ゲームが完了しているかどうか。
  private boolean isGameOver = false;
  // 現在のターン（先手か後手か）
  private Flag currentTurn = Flag.Black;

  private View.OnClickListener onClickListener = new View.OnClickListener() {
    @Override
    public void onClick(View button) {
      RectButton rect = (RectButton) button;
      // 既にゲームオーバーなら何もしない。
      if (isGameOver)
        return;
      // 既にOかXのどちらかが占領しているときは何もしない。
      if (rect.hasFlag())
        return;
      try {
        occupy(rect);
      } catch (GameOverException ex) {
        Toast.makeText(OXGameActivity.this, ex.getMessage(), Toast.LENGTH_LONG).show();
      }
    }
  };
  
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);

    rectButtons[0] = (RectButton) findViewById(R.id.left_top);
    rectButtons[1] = (RectButton) findViewById(R.id.top);
    rectButtons[2] = (RectButton) findViewById(R.id.right_top);
    rectButtons[3] = (RectButton) findViewById(R.id.left);
    rectButtons[4] = (RectButton) findViewById(R.id.center);
    rectButtons[5] = (RectButton) findViewById(R.id.right);
    rectButtons[6] = (RectButton) findViewById(R.id.left_bottom);
    rectButtons[7] = (RectButton) findViewById(R.id.bottom);
    rectButtons[8] = (RectButton) findViewById(R.id.right_bottom);

    for (RectButton ib : rectButtons) {
      ib.setOnClickListener(onClickListener);
    }
  }
  
  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    super.onCreateOptionsMenu(menu);
    menu.add(0, 0, 0, "新規ゲーム");
    return true;
  }

  @Override
  public boolean onMenuItemSelected(int featureId, MenuItem item) {
    super.onMenuItemSelected(featureId, item);
    switch (item.getItemId()) {
    case 0: // 新規ゲーム
      resetGame();
    }
    return true;
  }
  
  private void resetGame() {
    for (RectButton ib : rectButtons)
      ib.setFlag(Flag.None);
    currentTurn = Flag.Black;
    isGameOver = false;
  }

  private void occupy(RectButton rect) throws GameOverException {
    rect.setFlag(currentTurn);
    
    String message = String.format("%sの勝ち！", currentTurn == Flag.Black ? "○" : "×");
    // 水平ライン
    if (check(0, 1, 2) || check(3, 4, 5) || check(6, 7, 8))
      isGameOver = true;
    // 垂直ライン
    if (check(0, 3, 6) || check(1, 4, 7) || check(2, 5, 8))
      isGameOver = true;
    // クロスライン
    if (check(0, 4, 8) || check(2, 4, 6))
      isGameOver = true;
    if (isGameOver)
      throw new GameOverException(message);
    // 引き分け
    boolean isDrow = true;
    for (RectButton button : rectButtons) {
      if (button.getFlag() == Flag.None)
        isDrow = false;
    }
    if (isDrow) {
      isGameOver = true;
      throw new GameOverException("引き分け！");
    }
    turnOver();
  }

  private void turnOver() {
    if (currentTurn == Flag.Black)
      currentTurn = Flag.White;
    else
      currentTurn = Flag.Black;
  }
  
  private boolean check(int indexA, int indexB, int indexC) {
    if (rectButtons[indexA].getFlag() == rectButtons[indexB].getFlag()
        && rectButtons[indexB].getFlag() == rectButtons[indexC].getFlag()) {
      if (rectButtons[indexA].getFlag() != Flag.None)
        // 引数に指定されたインデックスのボタンがすべて同じOXなら「上がり」となる。
        return true;
    }
    return false;
  }
}