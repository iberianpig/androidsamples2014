package com.mamezou.android.ui.oxgame.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;

import com.mamezou.android.ui.oxgame.Flag;
import com.mamezou.android.ui.oxgame.GameOverException;
import com.mamezou.android.ui.oxgame.R;

public class OXGameWidget extends RelativeLayout {
	// ゲームが完了しているかどうか。
	private boolean isGameOver = false;
	// 先手(Oのこと)かどうか。
	// private boolean isBlack = true;
	private Flag currentTurn = Flag.Black;
	// OXGamePanelが保持しているRectButtonたち。
	private RectButton[] rectButtons = new RectButton[9];
	// GameOverになったときに実行するリスナーたち。
	private OnGameOverListener onGameOverListener;

	// GameOverの時に発行されるイベントリスナー。
	public interface OnGameOverListener {
		void onGameOver(Flag winner);
	}

	public OXGameWidget(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init(context);
	}

	public OXGameWidget(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}

	public OXGameWidget(Context context) {
		super(context);
		init(context);
	}

	public void reset() {
		for (RectButton button : rectButtons)
			button.setFlag(Flag.None);
		currentTurn = Flag.Black;
		isGameOver = false;
	}

	public void setOnGameOverListener(OnGameOverListener listener) {
		onGameOverListener = listener;
	}

	private void dispatchOnGameOverEvent(Flag winner) {
		if (onGameOverListener != null)
			onGameOverListener.onGameOver(winner);
	}

	private void init(Context context) {
		// 9個のRectButtonのインスタンスのひな形を作成する。
		for (int i = 0; i < 9; i++) {
			rectButtons[i] = new RectButton(context);
			rectButtons[i].setId(i);
			rectButtons[i].setBackgroundResource(R.drawable.none);
			rectButtons[i].setOnClickListener(onClickListener);
		}

		// center
		RelativeLayout.LayoutParams lp4 = new RelativeLayout.LayoutParams(75,
				75);
		lp4.setMargins(20, 20, 20, 20);
		lp4.addRule(CENTER_IN_PARENT);
		addView(rectButtons[4], lp4);
		// top
		RelativeLayout.LayoutParams lp1 = new RelativeLayout.LayoutParams(75,
				75);
		lp1.addRule(ALIGN_LEFT, 4);
		lp1.addRule(ABOVE, 4);
		addView(rectButtons[1], lp1);
		// bottom
		RelativeLayout.LayoutParams lp7 = new RelativeLayout.LayoutParams(75,
				75);
		lp7.addRule(ALIGN_LEFT, 4);
		lp7.addRule(BELOW, 4);
		addView(rectButtons[7], lp7);
		// left
		RelativeLayout.LayoutParams lp3 = new RelativeLayout.LayoutParams(75,
				75);
		lp3.addRule(LEFT_OF, 4);
		lp3.addRule(ALIGN_TOP, 4);
		addView(rectButtons[3], lp3);
		// left_top
		RelativeLayout.LayoutParams lp0 = new RelativeLayout.LayoutParams(75,
				75);
		lp0.addRule(ALIGN_TOP, 1);
		lp0.addRule(ALIGN_LEFT, 3);
		addView(rectButtons[0], lp0);
		// left_bottom
		RelativeLayout.LayoutParams lp6 = new RelativeLayout.LayoutParams(75,
				75);
		lp6.addRule(ALIGN_BOTTOM, 7);
		lp6.addRule(ALIGN_LEFT, 3);
		addView(rectButtons[6], lp6);
		// right
		RelativeLayout.LayoutParams lp5 = new RelativeLayout.LayoutParams(75,
				75);
		lp5.addRule(RIGHT_OF, 4);
		lp5.addRule(ALIGN_TOP, 4);
		addView(rectButtons[5], lp5);
		// right_top
		RelativeLayout.LayoutParams lp2 = new RelativeLayout.LayoutParams(75,
				75);
		lp2.addRule(ALIGN_TOP, 1);
		lp2.addRule(ALIGN_RIGHT, 5);
		addView(rectButtons[2], lp2);
		// right_bottom
		RelativeLayout.LayoutParams lp8 = new RelativeLayout.LayoutParams(75,
				75);
		lp8.addRule(ALIGN_BOTTOM, 7);
		lp8.addRule(ALIGN_RIGHT, 5);
		addView(rectButtons[8], lp8);
	}

	private View.OnClickListener onClickListener = new View.OnClickListener() {
		@Override
		public void onClick(View button) {
			if (isGameOver)
				return; // 既にゲームオーバーなら何もしない。
			RectButton rect = (RectButton) button;
			if (rect.hasFlag())
				return; // 既にOかXのどちらかが占領しているときは何もしない。
			try {
				occupy(rect);
			} catch (GameOverException ex) {
				isGameOver = true;
				dispatchOnGameOverEvent(ex.getWinner());
			}
		}
	};

	private void occupy(RectButton rect) throws GameOverException {
		rect.setFlag(currentTurn);
		// 水平ライン
		if (check(0, 1, 2) || check(3, 4, 5) || check(6, 7, 8))
			throw new GameOverException(rect.getFlag());
		// 垂直ライン
		if (check(0, 3, 6) || check(1, 4, 7) || check(2, 5, 8))
			throw new GameOverException(rect.getFlag());
		// クロスライン
		if (check(0, 4, 8) || check(2, 4, 6))
			throw new GameOverException(rect.getFlag());
		// 引き分けを判定する
		boolean isDrow = true;
		for (RectButton button : rectButtons) {
			if (button.getFlag() == Flag.None)
				isDrow = false;
		}
		if (isDrow)
			throw new GameOverException(Flag.None);
		// 攻守交代
		turnOver();
	}

	private void turnOver() {
		if (currentTurn == Flag.Black)
			currentTurn = Flag.White;
		else
			currentTurn = Flag.Black;
	}

	private boolean check(int indexA, int indexB, int indexC) {
		if (rectButtons[indexA].getFlag() == rectButtons[indexB].getFlag()
				&& rectButtons[indexB].getFlag() == rectButtons[indexC]
						.getFlag()) {
			if (rectButtons[indexA].getFlag() != Flag.None)
				// 引数に指定されたインデックスのボタンがすべて同じOXなら「上がり」となる。
				return true;
		}
		return false;
	}
}
