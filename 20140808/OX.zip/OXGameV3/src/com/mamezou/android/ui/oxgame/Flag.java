package com.mamezou.android.ui.oxgame;

public enum Flag {
	Black, White, None
}
