package com.mamezou.android.ui.oxgame;

public class GameOverException extends Exception {
	private Flag winner = Flag.None;

	public GameOverException(Flag winner) {
		super();
		this.winner = winner;
	}

	public GameOverException() {
		super();
	}

	public GameOverException(String detailMessage, Throwable throwable) {
		super(detailMessage, throwable);
	}

	public GameOverException(String detailMessage) {
		super(detailMessage);
	}

	public GameOverException(Throwable throwable) {
		super(throwable);
	}

	public Flag getWinner() {
		return winner;
	}
}
