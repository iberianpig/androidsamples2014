package com.mamezou.android.ui.oxgame;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.mamezou.android.ui.oxgame.widget.OXGameWidget;
import com.mamezou.android.ui.oxgame.widget.OXGameWidget.OnGameOverListener;

public class OXGameActivity extends Activity {
	private OXGameWidget game;
	// どちらかが勝つか、引き分けるかしてゲームが終わったときのイベントリスナー。
	private OnGameOverListener onGameOverListener = new OXGameWidget.OnGameOverListener() {
		@Override
		public void onGameOver(Flag winner) {
			String message = null;
			switch (winner) {
			case Black:
				message = "○の勝ち！";
				break;
			case White:
				message = "×の勝ち！";
				break;
			case None:
				message = "引き分け！";
			}
			Toast.makeText(OXGameActivity.this, message, Toast.LENGTH_LONG)
					.show();
		}
	};

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		game = (OXGameWidget) findViewById(R.id.oxgame);
		// どちらかが勝つか、引き分けるかしてゲームが終わったときに呼び出されるイベントリスナーを設定する。
		game.setOnGameOverListener(onGameOverListener);
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		boolean result = super.onMenuItemSelected(featureId, item);
		switch (item.getItemId()) {
		case 0: // 新規ゲーム
			game.reset();
			break;
		}
		return result;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		menu.add(0, 0, 0, "新規ゲーム");
		return true;
	}
}