/** Automatically generated file. DO NOT MODIFY */
package com.mamezou.android.ui.oxgame;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}