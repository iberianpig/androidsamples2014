package com.mamezou.android.ui.oxgame;

public class GameOverException extends Exception {
	private static final long serialVersionUID = 4971037124688760157L;

	public GameOverException() {
		super();
	}

	public GameOverException(String detailMessage, Throwable throwable) {
		super(detailMessage, throwable);
	}

	public GameOverException(String detailMessage) {
		super(detailMessage);
	}

	public GameOverException(Throwable throwable) {
		super(throwable);
	}
}
