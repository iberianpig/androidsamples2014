package com.mamezou.android.ui.oxgame;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class OXGameActivity extends Activity {
	// すべてのImageButtonに同じ処理をすることが多いのでリストを作成しておく。
	private ImageButton[] rectButtons = new ImageButton[9];
	// ゲームが完了しているかどうか。
	private boolean isGameOver = false;
	// 現在のターン（先手か後手か）
	private Flag currentTurn = Flag.Black;
	// ImageButtonでは、それがOかXのどちらにマークされているかわからないため、
	// 外側(Activity)でどちらにマークされているかを管理する必要がある。
	private ArrayList<Integer> blackTerritories = new ArrayList<Integer>();
	private ArrayList<Integer> whiteTerritories = new ArrayList<Integer>();

	private View.OnClickListener onClickListener = new View.OnClickListener() {
		@Override
		public void onClick(View button) {
			// 既にゲームオーバーなら何もしない。
			if (isGameOver)
				return;
			// 既にOかXのどちらかが占領しているときは何もしない。
			if (blackTerritories.contains(button.getId())
					|| whiteTerritories.contains(button.getId()))
				return;
			try {
				occupy(button);
			} catch (GameOverException ex) {
				Toast.makeText(OXGameActivity.this, ex.getMessage(),
						Toast.LENGTH_LONG).show();
			}
		}
	};

	@Override
	public void onCreate(Bundle savedInstanceState) { // ・・・⑧
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		rectButtons[0] = (ImageButton) findViewById(R.id.left_top);
		rectButtons[1] = (ImageButton) findViewById(R.id.top);
		rectButtons[2] = (ImageButton) findViewById(R.id.right_top);
		rectButtons[3] = (ImageButton) findViewById(R.id.left);
		rectButtons[4] = (ImageButton) findViewById(R.id.center);
		rectButtons[5] = (ImageButton) findViewById(R.id.right);
		rectButtons[6] = (ImageButton) findViewById(R.id.left_bottom);
		rectButtons[7] = (ImageButton) findViewById(R.id.bottom);
		rectButtons[8] = (ImageButton) findViewById(R.id.right_bottom);

		for (ImageButton ib : rectButtons)
			ib.setOnClickListener(onClickListener);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) { // ・・・⑨
		super.onCreateOptionsMenu(menu);
		menu.add(0, 0, 0, "新規ゲーム");
		return true;
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) { // ・・・⑩
		super.onMenuItemSelected(featureId, item);
		switch (item.getItemId()) {
		case 0: // 新規ゲーム
			resetGame();
		}
		return true;
	}

	private void resetGame() {
		for (ImageButton ib : rectButtons)
			ib.setBackgroundResource(R.drawable.none);
		blackTerritories.clear();
		whiteTerritories.clear();
		currentTurn = Flag.Black;
		isGameOver = false;
	}

	private void occupy(View rect) throws GameOverException {
		boolean isBlack = currentTurn == Flag.Black;
		rect.setBackgroundResource(isBlack ? R.drawable.black
				: R.drawable.white);
		List<Integer> territories = isBlack ? blackTerritories
				: whiteTerritories;
		territories.add(rect.getId());

		String message = String.format("%sの勝ち！", isBlack ? "○" : "×");
		// 水平ライン
		if (check(territories, R.id.left_top, R.id.top, R.id.right_top)
				|| check(territories, R.id.left, R.id.center, R.id.right)
				|| check(territories, R.id.left_bottom, R.id.bottom,
						R.id.right_bottom))
			isGameOver = true;
		// 垂直ライン
		if (check(territories, R.id.left_top, R.id.left, R.id.left_bottom)
				|| check(territories, R.id.top, R.id.center, R.id.bottom)
				|| check(territories, R.id.right_top, R.id.right,
						R.id.right_bottom))
			isGameOver = true;
		// クロスライン
		if (check(territories, R.id.left_top, R.id.center, R.id.right_bottom)
				|| check(territories, R.id.right_top, R.id.center,
						R.id.left_bottom))
			isGameOver = true;
		// 引き分け
		if (blackTerritories.size() + whiteTerritories.size() >= 9) {
			message = "引き分け！";
			isGameOver = true;
		}
		if (isGameOver)
			throw new GameOverException(message);
		turnOver();
	}

	private void turnOver() {
		if (currentTurn == Flag.Black)
			currentTurn = Flag.White;
		else
			currentTurn = Flag.Black;
	}

	private boolean check(List<Integer> buttons, int a, int b, int c) {
		return buttons.contains(a) && buttons.contains(b)
				&& buttons.contains(c);
	}
}